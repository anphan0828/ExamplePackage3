# ExamplePackage2

This should appear on PyPI as a proper README file
